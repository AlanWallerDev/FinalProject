package com.example.multibluetoothtesting;

import android.Manifest;
import android.bluetooth.BluetoothDevice;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;

import com.ramimartin.multibluetooth.activity.BluetoothActivity;

public class MainActivity extends BluetoothActivity implements DiscoveredDialogFragment.DiscoveredDialogListener{

    private static final int PERMISSION_REQUEST_COARSE_LOCATION = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //***** IMPORTANT FOR ANDROID SDK >= 6.0 *****//
        if (Build.VERSION.SDK_INT >= 23) {
            int permissionCheck = this.checkSelfPermission("Manifest.permission.ACCESS_FINE_LOCATION");
            permissionCheck += this.checkSelfPermission("Manifest.permission.ACCESS_COARSE_LOCATION");
            if (permissionCheck != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION}, PERMISSION_REQUEST_COARSE_LOCATION);
            } else {
                // TODO stuff if u need
            }
        } else {
            // TODO stuff if u need
        }
    }

    @Override
    public String setUUIDappIdentifier() {
        return "e0917680-d427-11e4-8830";
    }

    @Override
    public int myNbrClientMax() {
        return 7;
    }

    @Override
    public void onBluetoothStartDiscovery() {
    }

    @Override
    public void onBluetoothDeviceFound(BluetoothDevice device) {
    }

    @Override
    public void onClientConnectionSuccess() {
    }

    @Override
    public void onClientConnectionFail() {
    }

    @Override
    public void onServeurConnectionSuccess() {
    }

    @Override
    public void onServeurConnectionFail() {
    }

    @Override
    public void onBluetoothMsgStringReceived(String messageReceive) {
    }

    @Override
    public void onBluetoothMsgObjectReceived(Object o) {
    }

    @Override
    public void onBluetoothMsgBytesReceived(byte[] bytes) {
    }

    @Override
    public void onBluetoothNotAviable() {
    }

    @Override
    public void onDeviceSelectedForConnection(String addressMac) {

    }

    @Override
    public void onScanClicked() {

    }
}